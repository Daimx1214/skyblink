#!/bin/bash
# Retry comet_case until it produces a manifest (IRSA is flaky at night).
cd ~/workspace/space-apps-2026/skyblink
# wait for any already-running attempt to finish first
while pgrep -f 'scripts/comet_case.py' > /dev/null; do sleep 30; done
for i in 1 2 3 4 5 6; do
  if [ -f apps/web/cache/case-3iatlas/manifest.json ]; then break; fi
  echo "watchdog attempt $i $(date)" >> comet_watchdog.log
  .venv/bin/python scripts/comet_case.py >> comet_watchdog.log 2>&1
  if [ -f apps/web/cache/case-3iatlas/manifest.json ]; then break; fi
  sleep 300
done
if [ -f apps/web/cache/case-3iatlas/manifest.json ]; then
  .venv/bin/python scripts/bundle_cache.py >> comet_watchdog.log 2>&1
  echo "COMET_DONE $(date)" >> comet_watchdog.log
fi
