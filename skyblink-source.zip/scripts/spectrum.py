#!/usr/bin/env python3
"""Extract a REAL 102-channel SPHEREx spectrum for Barnard's Star from the
DR1 spectral-cube collection (spherex_dr1_cube) via IRSA SIA + the cutout
service. Aperture photometry per spectral plane at the Gaia-propagated
position. Output: apps/web/cache/barnards-star/spectrum.json

Honest labelling: aperture fluxes in mJy via the documented conversion
[mJy] = [MJy/sr] x 23.5045 x (pixscale_arcsec)^2 / 1000 per pixel, summed
over the aperture minus an annulus background. This is the star's measured
spectrum in SPHEREx's own cubes - not a model.
"""
import io
import json
import os
import time

import numpy as np
import requests
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.wcs import WCS
from astroquery.ipac.irsa import Irsa

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "apps", "web", "cache", "barnards-star", "spectrum.json")
RA, DEC = 269.4464, 4.7671          # Gaia-propagated position, epoch ~2025.6
CACHE_FITS = os.path.join(ROOT, "data", "cache", "barnard_cube_cutout.fits")


def sia_query():
    coord = SkyCoord(RA, DEC, unit="deg")
    last = None
    for i in range(4):
        try:
            return Irsa.query_sia(pos=(coord, 0.35 * u.deg),
                                  collection=["spherex_dr1_cube"])
        except Exception as e:  # noqa: BLE001
            last = e
            print(f"  SIA retry {i+1}/4: {type(e).__name__}", flush=True)
            time.sleep(25 * (i + 1))
    raise last


def download(url):
    last = None
    for i in range(6):
        try:
            r = requests.get(url, timeout=300)
            if r.status_code == 200 and len(r.content) > 10000:
                return r.content
            print(f"  fetch {r.status_code} len={len(r.content)}, retry", flush=True)
        except Exception as e:  # noqa: BLE001
            last = e
            print(f"  fetch error {type(e).__name__}, retry", flush=True)
        time.sleep(20 * (i + 1))
    raise RuntimeError(f"download failed: {last}")


def main():
    if os.path.exists(OUT):
        print("spectrum.json already exists"); return
    cube_bytes = None
    if os.path.exists(CACHE_FITS):
        cube_bytes = open(CACHE_FITS, "rb").read()
        print("using cached cube cutout", len(cube_bytes) // 1024, "KB")
    else:
        t = sia_query()
        print("cube rows:", len(t))
        if len(t) == 0:
            raise SystemExit("no cube rows for Barnard field")
        # nearest cube tile centre to the target
        dra = (t["s_ra"] - RA) * np.cos(np.deg2rad(DEC))
        d = np.hypot(np.asarray(dra), np.asarray(t["s_dec"]) - DEC)
        row = t[int(np.argmin(d))]
        base = str(row["access_url"])
        url = f"{base}?center={RA},{DEC}d&size={0.0833:.4f}"
        print("cutout:", url[:140])
        cube_bytes = download(url)
        os.makedirs(os.path.dirname(CACHE_FITS), exist_ok=True)
        open(CACHE_FITS, "wb").write(cube_bytes)
        print("downloaded", len(cube_bytes) // 1024, "KB")

    hdul = fits.open(io.BytesIO(cube_bytes))
    hdul.info()
    cube_hdu = None
    for h in hdul:
        if h.data is not None and h.data.ndim == 3:
            cube_hdu = h
            break
    if cube_hdu is None:
        raise SystemExit("no 3D cube HDU found; see HDU list above")
    data = np.asarray(cube_hdu.data, dtype=np.float64)  # (nspec, ny, nx)
    print("cube shape:", data.shape, "BUNIT:", cube_hdu.header.get("BUNIT"))
    w = WCS(cube_hdu.header, fobj=hdul, naxis=2)
    px, py = w.world_to_pixel(SkyCoord(RA, DEC, unit="deg"))
    px, py = float(px), float(py)
    print(f"star pixel: {px:.1f}, {py:.1f}")
    cd = w.proj_plane_pixel_scales()
    pixscale = float(cd[0].to(u.arcsec).value)
    factor = 23.5045 * pixscale ** 2 / 1000.0  # MJy/sr -> mJy per pixel

    # spectral axis: prefer the WCS-WAVE table / spectral WCS; else CRVAL3 axis
    waves = None
    try:
        w3 = WCS(cube_hdu.header, fobj=hdul, naxis=3)
        idx = np.arange(data.shape[0])
        world = w3.pixel_to_world(idx, idx * 0, idx * 0)  # placeholder
    except Exception:  # noqa: BLE001
        pass
    hdr = cube_hdu.header
    if "CRVAL3" in hdr and hdr.get("CTYPE3", "").upper().startswith(("WAVE", "FREQ")):
        crval, cdelt, crpix = hdr["CRVAL3"], hdr.get("CDELT3", 1.0), hdr.get("CRPIX3", 1.0)
        axis = crval + (np.arange(data.shape[0]) + 1 - crpix) * cdelt
        if hdr.get("CTYPE3", "").upper().startswith("FREQ"):
            waves = (299792458.0 / axis) * 1e6  # Hz -> um
        else:
            unit = (hdr.get("CUNIT3") or "um").lower()
            waves = axis * (1e3 if unit == "nm" else 1.0)  # nm->um guard
    if waves is None:
        raise SystemExit(f"no spectral WCS axis; CTYPE3={hdr.get('CTYPE3')}")

    yy, xx = np.mgrid[0:data.shape[1], 0:data.shape[2]]
    r2 = (xx - px) ** 2 + (yy - py) ** 2
    ap = r2 <= 2.0 ** 2
    ann = (r2 > 5.0 ** 2) & (r2 <= 8.0 ** 2)
    flux = []
    for i in range(data.shape[0]):
        plane = data[i]
        bg = np.nanmedian(plane[ann])
        flux.append(float(np.nansum((plane - bg)[ap]) * factor))
    order = np.argsort(waves)
    payload = {
        "target": "Barnard's Star",
        "source": "SPHEREx DR1 spectral cube (spherex_dr1_cube) via IRSA SIA cutout",
        "wave_um": [round(float(waves[i]), 3) for i in order],
        "flux_mjy": [round(flux[i], 2) for i in order],
        "note": "Aperture flux (r=2 px, annulus background) per spectral plane at the "
                "Gaia-propagated position; zodiacal background is modelled in the "
                "archive product, not subtracted from Level-2 planes, so treat the "
                "continuum shape as indicative and the absorption structure as real.",
    }
    json.dump(payload, open(OUT, "w"), indent=1)
    print("wrote", OUT, "channels:", len(order))


if __name__ == "__main__":
    main()
