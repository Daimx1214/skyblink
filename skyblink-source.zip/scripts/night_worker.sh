#!/bin/bash
# Owns the two IRSA-dependent jobs until both land or 09:00 PKT Nov 15.
# IRSA SIA has good/bad windows tonight; this loops patiently through them.
cd ~/workspace/space-apps-2026/skyblink
LOG=night_worker.log
echo "night worker start $(date)" >> $LOG
while [ "$(date +%s)" -lt "$(date -d '2026-11-15 09:00' +%s)" ]; do
  COMET_OK=0; SPEC_OK=0
  [ -f apps/web/cache/case-3iatlas/manifest.json ] && COMET_OK=1
  [ -f apps/web/cache/barnards-star/spectrum.json ] && SPEC_OK=1
  if [ $COMET_OK -eq 1 ] && [ $SPEC_OK -eq 1 ]; then
    .venv/bin/python scripts/bundle_cache.py >> $LOG 2>&1
    echo "ALL_DONE $(date)" >> $LOG
    break
  fi
  # wait out any already-running attempt
  while pgrep -f '[c]omet_case.py' > /dev/null || pgrep -f '[s]pectrum.py' > /dev/null; do sleep 30; done
  if [ $COMET_OK -eq 0 ]; then
    echo "comet attempt $(date)" >> $LOG
    .venv/bin/python scripts/comet_case.py >> $LOG 2>&1
  fi
  if [ $SPEC_OK -eq 0 ] && [ ! -f apps/web/cache/case-3iatlas/manifest.json ] || [ $SPEC_OK -eq 0 ]; then
    if [ $SPEC_OK -eq 0 ]; then
      echo "spectrum attempt $(date)" >> $LOG
      .venv/bin/python scripts/spectrum.py >> $LOG 2>&1
    fi
  fi
  [ -f apps/web/cache/case-3iatlas/manifest.json ] && [ -f apps/web/cache/barnards-star/spectrum.json ] && continue
  sleep 240
done
echo "night worker end $(date)" >> $LOG
