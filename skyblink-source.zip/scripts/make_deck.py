#!/usr/bin/env python3
"""Build the 7-slide SkyBlink backup deck (docs/skyblink-deck.pptx).

All imagery is the project's own real data: SPHEREx frames and context
renders from apps/web/cache, plus a spectrum chart plotted from the
bundled spectrum.json. Dark theme matches the site.
"""
import os

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Inches, Pt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "apps", "web", "cache")
OUT = os.path.join(ROOT, "docs", "skyblink-deck.pptx")
CHART = "/tmp/spec-chart.png"

BG = RGBColor(0x0A, 0x0F, 0x24)
PANEL = RGBColor(0x12, 0x1B, 0x3E)
GOLD = RGBColor(0xF2, 0xB1, 0x34)
TEAL = RGBColor(0x2E, 0xC4, 0xB6)
TEXT = RGBColor(0xE8, 0xEC, 0xF8)
MUTED = RGBColor(0x9A, 0xA7, 0xC7)
FONT = "Calibri"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
W, H = 13.333, 7.5


def slide():
    s = prs.slides.add_slide(BLANK)
    r = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    r.fill.solid()
    r.fill.fore_color.rgb = BG
    r.line.fill.background()
    r.shadow.inherit = False
    return s


def tx(s, x, y, w, h, text, size=18, color=TEXT, bold=False, align=PP_ALIGN.LEFT,
       space_after=6):
    box = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    lines = text.split("\n")
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = ln
        p.alignment = align
        p.space_after = Pt(space_after)
        for run in p.runs:
            run.font.name = FONT
            run.font.size = Pt(size)
            run.font.bold = bold
            run.font.color.rgb = color
    return box


def bar(s, x, y, w=0.85, color=GOLD):
    r = s.shapes.add_shape(1, Inches(x), Inches(y), Inches(w), Inches(0.055))
    r.fill.solid()
    r.fill.fore_color.rgb = color
    r.line.fill.background()
    r.shadow.inherit = False
    return r


def pic(s, path, x, y, w=None, h=None, border=TEAL):
    kw = {}
    if w: kw["width"] = Inches(w)
    if h: kw["height"] = Inches(h)
    p = s.shapes.add_picture(path, Inches(x), Inches(y), **kw)
    if border:
        p.line.color.rgb = border
        p.line.width = Pt(1.2)
    p.shadow.inherit = False
    return p


def heading(s, text, sub=None):
    bar(s, 0.7, 0.62)
    tx(s, 0.7, 0.78, 12.0, 0.9, text, size=33, bold=True)
    if sub:
        tx(s, 0.7, 1.52, 12.0, 0.6, sub, size=17, color=MUTED)


def footer(s, n):
    tx(s, 0.7, 7.08, 8.0, 0.3, "SkyBlink · Team Sohan Halwa · NASA Space Apps 2026",
       size=11, color=MUTED)
    tx(s, 12.3, 7.08, 0.5, 0.3, str(n), size=11, color=MUTED, align=PP_ALIGN.RIGHT)


# ---------------- Slide 1: Title ----------------
s = slide()
pic(s, os.path.join(CACHE, "barnards-star", "context.jpg"), 6.1, 0, h=7.5, border=None)
shade = s.shapes.add_shape(1, Inches(6.1), 0, Inches(1.6), prs.slide_height)
shade.fill.solid(); shade.fill.fore_color.rgb = BG; shade.line.fill.background()
shade.shadow.inherit = False
# soften: overlay a translucent-looking panel is not supported simply; the
# solid strip above just anchors the split. Title block on the left:
tx(s, 0.7, 1.15, 6.4, 1.2, "SkyBlink", size=60, bold=True, color=GOLD)
tx(s, 0.7, 2.3, 5.7, 1.0,
   "Watch the sky change, in real NASA SPHEREx images.", size=24)
bar(s, 0.7, 3.42, color=TEAL)
tx(s, 0.7, 3.68, 5.9, 1.5,
   "A public blink comparator for the SPHEREx sky survey:\n"
   "the same field, months apart, one shared grid,\n"
   "so movers jump and variables pulse.", size=16, color=MUTED)
tx(s, 0.7, 5.3, 6.2, 1.0,
   "Team Sohan Halwa\nDaim Ali and Ali Abdullah", size=18, bold=True)
tx(s, 0.7, 6.3, 6.4, 0.7,
   "NASA Space Apps Challenge 2026 · Planet X and SPHEREx · Universal Event",
   size=13, color=MUTED)
tx(s, 8.3, 6.95, 4.6, 0.35,
   "One-degree context render, real SPHEREx exposure. Gold ring: Barnard's Star.",
   size=10.5, color=MUTED, align=PP_ALIGN.RIGHT)

# ---------------- Slide 2: The idea ----------------
s = slide()
heading(s, "A blink comparator for SPHEREx",
        "How astronomers have hunted moving objects for a century, rebuilt for a 102-channel survey")
tx(s, 0.7, 2.3, 6.0, 4.5,
   "SkyBlink aligns SPHEREx observations of the same field from different "
   "months (Data Release 1 and Quick Release 3, one uniformly processed "
   "set) on a shared north-up grid with one brightness stretch, and blinks "
   "them.\n\n"
   "Moving objects jump between frames. Variable stars pulse. Anything "
   "that still looks like a discovery is a candidate, and candidates are "
   "vetted with the Two-Epoch Check, a method we document and apply in "
   "our validation.\n\n"
   "The five challenge targets are pre-loaded and open instantly. A live "
   "search for new fields runs on our backend and stops with a clear "
   "message if the archive does not answer within about 20 seconds.", size=15.5)
pic(s, os.path.join(CACHE, "barnards-star", "frame_0.png"), 7.0, 2.3, w=2.75)
pic(s, os.path.join(CACHE, "barnards-star", "frame_4.png"), 10.05, 2.3, w=2.75)
tx(s, 7.0, 5.25, 2.75, 0.35, "27 Aug 2025 · DR1", size=13, color=MUTED,
   align=PP_ALIGN.CENTER)
tx(s, 10.05, 5.25, 2.75, 0.35, "21 Aug 2026 · QR3", size=13, color=MUTED,
   align=PP_ALIGN.CENTER)
tx(s, 7.0, 5.62, 5.8, 0.8,
   "Barnard's Star, the same field one year apart.\nBlink them: only the star has moved.",
   size=14.5, color=TEAL, align=PP_ALIGN.CENTER)
footer(s, 2)

# ---------------- Slide 3: Five dossiers ----------------
s = slide()
heading(s, "Five targets, five dossiers",
        "Every challenge target pre-loaded with frames, overlays, quality data and a spectrum")
targets = [("barnards-star", "Barnard's Star", "5 epochs"),
           ("epsilon-indi-b", "Epsilon Indi B", "4 epochs"),
           ("wise-0855", "WISE 0855", "4 epochs"),
           ("rw-aurigae", "RW Aurigae", "3 epochs"),
           ("r-draconis", "R Draconis", "3 epochs")]
x = 0.7
for slug, name, epochs in targets:
    pic(s, os.path.join(CACHE, slug, "context.jpg"), x, 2.35, w=2.32)
    tx(s, x, 3.95, 2.32, 0.4, name, size=15.5, bold=True, align=PP_ALIGN.CENTER)
    tx(s, x, 4.32, 2.32, 0.35, epochs, size=12.5, color=MUTED, align=PP_ALIGN.CENTER)
    x += 2.47
panel = s.shapes.add_shape(1, Inches(0.7), Inches(5.05), Inches(11.93), Inches(1.55))
panel.fill.solid(); panel.fill.fore_color.rgb = PANEL; panel.line.fill.background()
panel.shadow.inherit = False
tx(s, 1.0, 5.28, 11.4, 1.2,
   "In every dossier:  Blink / Side-by-side / Difference views  ·  Gaia DR3 overlay, proper motions\n"
   "propagated to each frame's date  ·  WISE overlay  ·  clean-pixel % and band per frame  ·\n"
   "detector-band flux chart  ·  coordinates in the URL  ·  3′ or 5′ field for live renders",
   size=16)
footer(s, 3)

# ---------------- Slide 4: Spectra ----------------
s = slide()
heading(s, "Real spectra, from real exposures",
        "Each point is one SPHEREx exposure: wavelength from its own spectral WCS, flux from aperture photometry")
pic(s, CHART, 0.7, 2.35, w=7.3, border=None)
tx(s, 8.45, 2.45, 4.2, 3.2,
   "Channels per target\n\n"
   "Barnard's Star · 74 (91 exposures)\n"
   "R Draconis · 25\n"
   "RW Aurigae · 24\n"
   "WISE 0855 · 24\n"
   "Epsilon Indi B · 14", size=17)
tx(s, 8.45, 5.35, 4.25, 1.3,
   "Photometric points, not a calibrated\n"
   "spectrum. Faint targets are near\n"
   "the noise.", size=14.5, color=GOLD)
footer(s, 4)

# ---------------- Slide 5: Case Files ----------------
s = slide()
heading(s, "Case Files: the method at work",
        "Three guided cases, real data end to end")
pic(s, os.path.join(CACHE, "case-3iatlas", "frame_0.png"), 0.7, 2.35, w=2.5)
pic(s, os.path.join(CACHE, "case-3iatlas", "frame_1.png"), 3.45, 2.35, w=2.5)
tx(s, 0.7, 4.95, 5.25, 1.6,
   "Case 1 · Comet 3I/ATLAS\n"
   "13 Aug 2025 and 14 Dec 2025: two visits,\n"
   "two positions 79.2° apart.", size=15.5)
tx(s, 6.45, 2.35, 6.2, 2.0,
   "Case 2 · The Two-Epoch Check\n"
   "Why a blinking candidate is not yet a discovery,\n"
   "and the test every candidate must pass.", size=15.5)
tx(s, 6.45, 4.15, 6.2, 2.4,
   "Case 3 · Barnard's Star, measured\n"
   "Centroided in all five epochs, its positions agree\n"
   "with Gaia's prediction to within 1.3 to 7.4 arcsec.\n"
   "The scatter's likeliest confound is stated on the\n"
   "page, and the data downloads as CSV.", size=15.5)
footer(s, 5)

# ---------------- Slide 6: Validation ----------------
s = slide()
heading(s, "Validated, not just described",
        "We hid fake movers in real data and measured what the blink test finds")
stats = [("540", "synthetic movers injected\ninto real epoch pairs"),
         ("100%", "recovered at 15 sigma\nand above"),
         ("97–98%", "recovered at 8 sigma\nfor shifts of 2 px or more"),
         ("439", "raw peaks in the control run:\nwhy vetting is not optional")]
x = 0.7
for big, small in stats:
    tx(s, x, 2.5, 2.85, 1.1, big, size=44, bold=True, color=GOLD,
       align=PP_ALIGN.CENTER)
    tx(s, x, 3.75, 2.85, 1.0, small, size=14.5, color=MUTED,
       align=PP_ALIGN.CENTER)
    x += 3.02
tx(s, 0.7, 5.15, 11.9, 1.2,
   "Injected sources are idealised Gaussians tested with our own rule. This measures the sensitivity\n"
   "of the difference test, not performance on real movers, and the site says so.",
   size=15.5, color=TEAL)
footer(s, 6)

# ---------------- Slide 7: Data and links ----------------
s = slide()
heading(s, "Data, links and team", "Everything public, everything checkable")
tx(s, 0.7, 2.3, 6.1, 3.6,
   "NASA data\n"
   "SPHEREx Level-2 images, DR1 and QR3, via IRSA\n"
   "DR1 images · DOI 10.26131/IRSA678\n"
   "DR1 cube · DOI 10.26131/IRSA679\n"
   "QR3 · DOI 10.26131/IRSA662\n\n"
   "Partner data\n"
   "ESA Gaia DR3 · SIMBAD (CDS) · Aladin Lite (CDS)\n"
   "SkyBoT (IMCCE) · Astropy stack", size=16)
tx(s, 7.1, 2.3, 5.6, 3.6,
   "Try it\n"
   "Live site · daimx1214.github.io/skyblink\n"
   "Demo video · 29 seconds, link in the project page\n"
   "Source · github.com/Daimx1214/skyblink\n"
   "Backend · skyblink-lyart.vercel.app\n\n"
   "No account. No tracking. Works on phones.", size=16)
panel = s.shapes.add_shape(1, Inches(0.7), Inches(5.95), Inches(11.93), Inches(0.95))
panel.fill.solid(); panel.fill.fore_color.rgb = PANEL; panel.line.fill.background()
panel.shadow.inherit = False
tx(s, 1.0, 6.12, 11.4, 0.7,
   "AI use: we used AI assistants for research, planning, drafting code and writing, under the team's direction. "
   "All data shown are real archive products; nothing is simulated.", size=13.5, color=MUTED)
tx(s, 0.7, 5.5, 11.9, 0.4,
   "Team Sohan Halwa · Daim Ali and Ali Abdullah · Universal Event",
   size=16, bold=True)
footer(s, 7)

prs.save(OUT)
print("saved", OUT, os.path.getsize(OUT), "bytes,", len(prs.slides.__iter__.__self__._sldIdLst), "slides")
