# Space Apps project page — paste-ready copy (Team Sohan Halwa · SkyBlink)

**Project name:** SkyBlink

**High-level summary (draft):**
SkyBlink is a public web tool that lets anyone enter the coordinates of a patch of
sky and watch it change over time in real NASA SPHEREx survey images — like a
little video of the sky. It lines up SPHEREx observations of the same field taken
months apart (Data Release 1 + Quick Release 3, one uniformly processed set),
aligns them on a shared grid with a shared brightness stretch, and blinks them:
moving objects jump, variable stars pulse, and false candidates fail our named
Two-Epoch Check. The five test targets named in the challenge — Barnard's Star,
Epsilon Indi B, WISE 0855, RW Aurigae and R Draconis — are pre-loaded, and a
guided Case File follows interstellar comet 3I/ATLAS between its August and
December 2025 visits.

**Demo:** (video ≤30 s — link after upload) · Backup: 7-slide deck.

**Live site:** (Pages URL) · **Code:** https://github.com/Daimx1214/skyblink

**Data & resources used:**
- SPHEREx Level-2 images + IRSA SIA/TAP archive services (IRSA at IPAC,
  NASA/JPL-Caltech & the SPHEREx team) — releases DR1 and QR3
- IRSA 3I/ATLAS observation table (comet positions per exposure)
- SPHEREx tutorial notebooks (IRSA) — cutout, spectral-WCS and photometry recipes
- ESA Gaia DR3 (DPAC) via ESA TAP — reference positions & proper motions
- SIMBAD (CDS) — name resolution; SkyBoT (IMCCE) — solar-system positions
- Aladin Lite / HiPS (CDS) — sky-browsing technology reference
- Astropy, astroquery, reproject, photutils (open-source Python astronomy stack)

**AI disclosure (paste as-is):**
AI assistants were used for research, planning and code drafting during this
hackathon, under the team's direction. All data shown are real archive products;
nothing is simulated.

**Team:** Daim Ali (owner) & Ali Abdullah — Team Sohan Halwa, Universal Event.
